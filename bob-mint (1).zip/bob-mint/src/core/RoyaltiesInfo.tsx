export interface RoyaltiesInfo {
    totalRoyalties: number,
    availableToClaim: string,
}