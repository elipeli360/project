import { BigNumber } from "ethers";

export interface Raffle {
    paused: boolean;
    poolId: BigNumber;
    players: string[];
    playerLimit: BigNumber;
    ticketPrice: BigNumber;
    nftContract: string;
    name: string;
    tokenId: BigNumber;
    rank: BigNumber;
    winner: string;
    history: string[];
}