import { Raffle } from "./Raffle";

export interface RafflePool {
    title: string;
    isRaffleActive: boolean;
    history: Raffle[];
}