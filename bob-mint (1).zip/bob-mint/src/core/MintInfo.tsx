export interface MintInfo {
    isPaused: boolean;
    price: number;
    whitelistPrice: number;
    supply: number;
    maxSupply: number;
    maxMint: number;
    publicTimestamp: number;
}