export interface MetadataNFT {
    name: string,
    image: string
}