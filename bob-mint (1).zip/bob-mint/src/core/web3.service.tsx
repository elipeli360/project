import { BigNumber, ethers } from "ethers";
import Web3Modal from "web3modal";
import { Subject, BehaviorSubject } from 'rxjs'
import { CONTRACT_ADDRESS, CONTRACT_ABI, SPACESHIPS_ADDRESS, SPACESHIPS_ABI, TOKENS_WALLET_ADDRESS, TOKENS_WALLET_ABI, ERC721_ABI, RAFFLE_ADDRESS, RAFFLE_ABI, BOB_MUTANTS_ADDRESS, BOB_MUTANTS_ABI, STAKING_ADDRESS, STAKING_ABI, SHOP_ADDRESS, SHOP_ABI, COIN_ABI, COIN_ADDRESS } from ".././config"
import { MintInfo } from "./MintInfo";
import { ChainModel } from "./ChainModel";

import WalletConnectProvider from "@walletconnect/web3-provider";
import { RoyaltiesInfo } from "./RoyaltiesInfo";
import { MetadataNFT } from "./MetadataNFT";
import { RafflePool } from "./RafflePool";
import { Raffle } from "./Raffle";
import { ShopItem } from "../components/ShopView";

export type StakeInfo = { enabled: boolean, totalClaimed: BigNumber, totalStaked: BigNumber, dailyRewards: BigNumber }

export default class Web3Service {
    static instance: Web3Service

    static shared() {
        if (Web3Service.instance) {
            return Web3Service.instance
        } else {
            Web3Service.instance = new Web3Service()
            return Web3Service.instance
        }
    }

    static cronosRpc = "https://rpc.vvs.finance";
    static defaultProvider = new ethers.providers.JsonRpcProvider(Web3Service.cronosRpc);

    // Private
    private _connected$ = new BehaviorSubject<boolean>(false)
    private _isLoading$ = new BehaviorSubject<boolean>(false)
    private _account$ = new BehaviorSubject<string | undefined>(undefined)
    private _mintInfo$ = new BehaviorSubject<MintInfo | undefined>(undefined)
    private _royalties$ = new BehaviorSubject<RoyaltiesInfo | undefined>(undefined)
    private _shipRoyalties$ = new BehaviorSubject<RoyaltiesInfo | undefined>(undefined)
    private _tokens$ = new Subject<number[]>()
    private _signature$ = new BehaviorSubject<string | undefined>(undefined)
    private _showToast$ = new Subject<{ title: string }>()
    private _errors$ = new Subject<string>()
    private _isWhitelisted$ = new BehaviorSubject<boolean>(false)
    private _raffles$ = new BehaviorSubject<{ id: number, isRaffleActive: boolean, raffle: Raffle | undefined, title: string | undefined, history: Raffle[] }[]>([])

    private _shopActiveItems$ = new Subject<ShopItem[]>()
    private _isShopManager$ = new Subject<boolean>()

    private _isApproved$ = new Subject<boolean>()
    private _stakedTokens$ = new Subject<number[]>()
    private _stakeInfo$ = new BehaviorSubject<StakeInfo | undefined>(undefined)
    private _stakeRewards$ = new BehaviorSubject<BigNumber | undefined>(undefined)

    private _bobBalance$ = new BehaviorSubject<BigNumber | undefined>(undefined)
    // Public

    public readonly connected$ = this._connected$.asObservable()
    public readonly account$ = this._account$.asObservable()
    public readonly mintInfo$ = this._mintInfo$.asObservable()
    public readonly royalties$ = this._royalties$.asObservable()
    public readonly shipRoyalties$ = this._shipRoyalties$.asObservable()
    public readonly tokens$ = this._tokens$.asObservable()
    public readonly signature$ = this._signature$.asObservable()
    public readonly showToast$ = this._showToast$.asObservable()
    public readonly errors$ = this._errors$.asObservable()
    public readonly isLoading$ = this._isLoading$.asObservable()
    public readonly isWhitelisted$ = this._isWhitelisted$.asObservable()
    public readonly raffles$ = this._raffles$.asObservable()

    public readonly shopActiveItems$ = this._shopActiveItems$.asObservable()
    public readonly isShopManager$ = this._isShopManager$.asObservable()

    public readonly isApproved$ = this._isApproved$.asObservable()
    public readonly stakedTokens$ = this._stakedTokens$.asObservable()
    public readonly stakeInfo$ = this._stakeInfo$.asObservable()
    public readonly stakeRewards$ = this._stakeRewards$.asObservable()

    public readonly bobBalance$ = this._bobBalance$.asObservable()

    // Logic
    private web3Modal: Web3Modal
    private provider?: ethers.providers.Web3Provider
    private didConnectOnLoad: boolean = false
    private connector: any

    private _chain = new ChainModel(
        25,
        "Cronos",
        "Crypto.org Coin",
        18,
        "CRO",
        ['https://evm.cronos.org']
    )

    constructor() {
        const providerOptions = {
            "custom-walletconnect": {
                display: {
                    logo: "https://docs.walletconnect.com/img/walletconnect-logo.svg",
                    name: "WalletConnect",
                    description: "Connect with any WalletConnect compatible wallet."
                },
                options: {
                    appName: 'Moon Crew Apes',
                    networkUrl: 'https://evm-cronos.crypto.org/',
                    chainId: 25
                },
                package: WalletConnectProvider,
                connector: async () => {
                    const connector = new WalletConnectProvider({
                        rpc: {
                            25: "https://evm-cronos.crypto.org"
                        },
                        chainId: 25,
                        bridge: 'https://derelay.rabby.io'
                    });
                    await connector.enable();
                    this.connector = connector;
                    return connector;
                }
            },
        }

        this.web3Modal = new Web3Modal({
            cacheProvider: true,
            providerOptions
        })
    }

    isCorrectChainId = () => {
        if (window.ethereum) return window.ethereum.networkVersion == this._chain.id
        return true
    }

    connectToCachedProvider = async () => {
        if (this.didConnectOnLoad || !this.web3Modal.cachedProvider) return

        this._isLoading$.next(true)
        this.didConnectOnLoad = true
        this.web3Modal.connectTo(this.web3Modal.cachedProvider)
            .then(provider => {
                this.walletConnected(provider)
                this._isLoading$.next(false)
            })
            .catch(error => {
                this._errors$.next("Failed to connect")
                this._isLoading$.next(false)
            })
    }

    toggleConnect = async () => {
        if (this._connected$.value) {
            try {
                this.connector.disconnect();
            }
            catch (error) {
            }
            try {
                this.connector.deactivate();
            }
            catch (error) {
            }

            this.disconnect()
        } else {
            this.connectToWallet()
        }
    }

    switchNetwork = async () => {
        if (this.isCorrectChainId()) return

        try {
            await window.ethereum.request({
                method: 'wallet_switchEthereumChain',
                params: [{ chainId: ethers.utils.hexValue(this._chain.id) }]
            })
        } catch (err: any) {
            if (err.code == 4902) {
                await window.ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: [{
                        chainName: this._chain.name,
                        chainId: ethers.utils.hexValue(this._chain.id),
                        nativeCurrency: { name: this._chain.currencyName, decimals: this._chain.decimals, symbol: this._chain.symbol },
                        rpcUrls: this._chain.rpcUrls
                    }]
                })
            } else if (err.code == 4901) {
                return
            } else {
                this._errors$.next('There was a problem adding ' + this._chain.name + ' network to MetaMask')
            }
        }
    }

    private walletConnected(provider: any) {
        this.provider = new ethers.providers.Web3Provider(provider)
        this._connected$.next(true)
        this._showToast$.next({ title: "Wallet connected" })
        this.getAccount()

        this.observeWalletChanges()
    }

    private observeWalletChanges() {
        this.removeListeners()

        const provider = new ethers.providers.Web3Provider(window.ethereum, "any")

        provider.on("network", (newNetwork, oldNetwork) => {
            if (oldNetwork) {
                window.location.reload()
            }
        })

        window.ethereum.on("accountsChanged", (accounts: string[]) => {
            if (accounts[0] && accounts[0] != this._account$.value) {
                this.getAccount()
            }
        })
    }

    private removeListeners() {
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any")
        provider.removeAllListeners()
    }

    private connectToWallet = async () => {
        this.web3Modal.clearCachedProvider()

        this._isLoading$.next(true)
        this.web3Modal.connect()
            .then(provider => {
                this._isLoading$.next(false)
                this.didConnectOnLoad = true
                this.walletConnected(provider)

            })
            .catch(error => {
                this._isLoading$.next(false)
                this._errors$.next("Failed to connect")
            })
    }

    private disconnect = async () => {
        this.web3Modal.clearCachedProvider()
        this._connected$.next(false)
        this._account$.next(undefined)
        this._mintInfo$.next(undefined)
    }

    private getAccount = async () => {
        if (!this.provider) return

        this._isLoading$.next(true)
        const signer = this.provider.getSigner();
        const address = (await signer.getAddress()).toLowerCase();
        this._account$.next(address)
        this._isLoading$.next(false)
    }

    // MINTING
    mint = async (amount: number) => {
        if (!this.provider || !this._account$.value) {
            this.connectToWallet()
            return
        }

        const signer = this.provider.getSigner()
        const contract = new ethers.Contract(BOB_MUTANTS_ADDRESS, BOB_MUTANTS_ABI, signer)

        this._isLoading$.next(true)
        try {
            const price = await contract.mintPrice(this._account$.value)
            const value = parseInt(ethers.utils.formatEther(price)) * amount

            const gasEstimated = await contract.estimateGas.mint(amount, { value: ethers.utils.parseEther(value.toString()) })
            const gas = Math.ceil(gasEstimated.toNumber() * 1.5)
            const gasNumber = BigNumber.from(gas)

            const tx = await contract.mint(amount, { value: ethers.utils.parseEther(value.toString()), gasLimit: gasNumber })
            await tx.wait()

            this._showToast$.next({ title: 'Minted ' + amount + " BOB Mutants" })
            this.getMintInfo()
        } catch (e) {
            console.log(e)
            this._errors$.next("Could not process transaction")
        } finally {
            this._isLoading$.next(false)
        }
    }

    getMintInfo = async () => {
        const contract = new ethers.Contract(BOB_MUTANTS_ADDRESS, BOB_MUTANTS_ABI, this.provider ?? Web3Service.defaultProvider)

        try {
            const mintInfo = await contract.getMintInfo()
            this._mintInfo$.next(mintInfo)
        } catch (e) {
            console.log(e)
        }
    }

    isWhitelisted = async () => {
        const contract = new ethers.Contract(BOB_MUTANTS_ADDRESS, BOB_MUTANTS_ABI, this.provider ?? Web3Service.defaultProvider)

        try {
            if (this._account$.value) {
                const isWhitelisted = await contract.isWhitelisted(this._account$.value)
                this._isWhitelisted$.next(isWhitelisted)
            }
        } catch {
            this._isWhitelisted$.next(false)
        }
    }

    // GALLERY
    getUserTokens = async (address: string) => {
        if (!this.provider || !this._account$.value) return

        const contract = new ethers.Contract(TOKENS_WALLET_ADDRESS, TOKENS_WALLET_ABI, this.provider)

        try {
            const tokens = await contract.tokensOfWallet(this._account$.value, address)
            this._tokens$.next(tokens)
        } catch (e) {
            this._tokens$.next([])
        }
    }

    // ROYALTIES
    getRoyalties = async () => {
        if (!this.provider || !this._account$.value) return

        const signer = this.provider.getSigner()
        const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer)

        try {
            const availableToClaim = Number(ethers.utils.formatEther(await contract.getRoyalties(this._account$.value))).toFixed(2)
            const totalRoyalties = Number(ethers.utils.formatEther(await contract.totalRoyalties()))
            this._royalties$.next({ totalRoyalties, availableToClaim })
        } catch (e) {
            //
        }
    }

    claimAllRoyalties = async () => {
        if (!this.provider || !this._account$.value) return

        const signer = this.provider.getSigner()
        const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer)

        try {
            const tx = await contract.claimAllRoyalties()
            await tx.wait()

            this._showToast$.next({ title: "Royalties have been claimed" })
        } catch (e) {
            this._errors$.next("Could not claim royalties")
        }
    }

    // SPACESHIPS ROYALTIES
    getSpaceshipsRoyalties = async () => {
        if (!this.provider || !this._account$.value) return

        const signer = this.provider.getSigner()
        const contract = new ethers.Contract(SPACESHIPS_ADDRESS, SPACESHIPS_ABI, signer)

        try {
            const availableToClaim = Number(ethers.utils.formatEther(await contract.getRoyalties(this._account$.value))).toFixed(2)
            const totalRoyalties = Number(ethers.utils.formatEther(await contract.totalRoyalties()))
            this._shipRoyalties$.next({ totalRoyalties, availableToClaim })
        } catch (e) {
            //
        }
    }

    claimAllSpacshipsRoyalties = async () => {
        if (!this.provider || !this._account$.value) return

        const signer = this.provider.getSigner()
        const contract = new ethers.Contract(SPACESHIPS_ADDRESS, SPACESHIPS_ABI, signer)

        try {
            const tx = await contract.claimAllRoyalties()
            await tx.wait()

            this._showToast$.next({ title: "Royalties have been claimed" })
        } catch (e) {
            this._errors$.next("Could not claim royalties")
        }
    }

    // ERC721
    approveForAll = async (erc721: string, operator: string) => {
        if (!this.provider || !this._account$.value) {
            this.connectToWallet();
            return
        }

        const signer = this.provider.getSigner()
        const contract = new ethers.Contract(erc721, ERC721_ABI, signer)

        try {
            const tx = await contract.setApprovalForAll(operator, true)
            await tx.wait()
        } catch (e) {
            console.log(e)
        }
    }

    isApproved = async (erc721: string, operator: string) => {
        if (!this.provider || !this._account$.value) return

        const contract = new ethers.Contract(erc721, ERC721_ABI, this.provider ?? Web3Service.defaultProvider)

        try {
            const isApproved = await contract.isApprovedForAll(this._account$.value, operator)
            this._isApproved$.next(isApproved)
        } catch (e) {
            this._isApproved$.next(false)
        }
    }

    // Raffle
    joinRaffle = async (poolId: number) => {
        if (!this.provider || !this._account$.value) {
            this.connectToWallet();
            return
        }

        const signer = this.provider.getSigner()
        const contract = new ethers.Contract(RAFFLE_ADDRESS, RAFFLE_ABI, signer)

        this._isLoading$.next(true)
        try {
            const price = await contract.price(poolId)

            const gasEstimated = await contract.estimateGas.joinRaffle(poolId, { value: price })
            const gas = Math.ceil(gasEstimated.toNumber() * 1.5)
            const gasNumber = BigNumber.from(gas)

            const tx = await contract.joinRaffle(poolId, { value: price, gasLimit: gasNumber })
            await tx.wait()

            this.getRaffle()
        } catch (e) {
            console.log(e)
        } finally {
            this._isLoading$.next(false)
        }
    }

    getRaffle = async () => {
        const contract = new ethers.Contract(RAFFLE_ADDRESS, RAFFLE_ABI, this.provider ?? Web3Service.defaultProvider)

        try {
            this._isLoading$.next(true)
            const pools: RafflePool[] = await contract.getAllPools()

            var allPools: { id: number, isRaffleActive: boolean, raffle: Raffle | undefined, title: string | undefined, history: Raffle[] }[] = []

            for (let index = 0; index < pools.length; index++) {
                const pool = pools[index];
                const raffle: Raffle | undefined = pool.history.length > 0 ? pool.history[pool.history.length - 1] : undefined
                if (raffle) {
                    const history = (pool.isRaffleActive ? pool.history.slice(0, -1) : pool.history).filter(h => h.players.length > 0)
                    allPools.push({ id: Number(raffle.poolId), isRaffleActive: pool.isRaffleActive, raffle: raffle, title: pool.title, history: history })
                } else {
                    allPools.push({ id: -1, isRaffleActive: false, raffle: undefined, title: pool.title, history: [] })
                }
            }

            this._raffles$.next(allPools)
        } catch (e) {
            console.error(e)
            this._raffles$.next([])
        } finally {
            this._isLoading$.next(false)
        }
    }

    getImage = async (address: string, tokenId: number): Promise<string | undefined> => {
        const erc721 = new ethers.Contract(address, ERC721_ABI, this.provider ?? Web3Service.defaultProvider)
        const tUri = await erc721.tokenURI(tokenId)
        const tokenUri = tUri.replace("ipfs://", "https://nftstorage.link/ipfs/")
        if (!tokenUri) {
            return undefined
        }

        var metadata: MetadataNFT
        try {
            metadata = await ethers.utils.fetchJson(tokenUri) as MetadataNFT
        } catch {
            return undefined
        }

        if (metadata.image.startsWith('ipfs://')) {
            return metadata.image.replace("ipfs://", "https://wsrv.nl/?url=https://nftstorage.link/ipfs/")
        } else {
            return `https://wsrv.nl/?url=${metadata.image}`
        }
    }

    // STAKING
    getStakeInfo = async () => {
        const contract = new ethers.Contract(STAKING_ADDRESS, STAKING_ABI, this.provider ?? Web3Service.defaultProvider)

        try {
            const info = await contract.stakeInfo()
            this._stakeInfo$.next(info)

            if (this._account$.value) {
                const stakedTokens = await contract.getTokenIdsForAddress(this._account$.value)
                this._stakedTokens$.next(stakedTokens)
            }
        } catch (e) {
            console.error(e)
        }
    }

    getUnclaimedRewardsForAddress = async () => {
        if (!this.provider || !this._account$.value) {
            return
        }

        const contract = new ethers.Contract(STAKING_ADDRESS, STAKING_ABI, this.provider ?? Web3Service.defaultProvider)

        try {
            const rewards = await contract.getUnclaimedRewardsForAddress(this._account$.value)
            this._stakeRewards$.next(rewards)
        } catch (e) {
            console.error(e)
        }
    }

    claimStakeRewards = async () => {
        if (!this.provider || !this._account$.value) return

        const signer = this.provider.getSigner()
        const contract = new ethers.Contract(STAKING_ADDRESS, STAKING_ABI, signer)

        try {
            const gasEstimated = await contract.estimateGas.claimRewardsForAddress(this._account$.value)
            const gas = Math.ceil(gasEstimated.toNumber() * 1.5)
            const gasNumber = BigNumber.from(gas)

            const tx = await contract.claimRewardsForAddress(this._account$.value, { gasLimit: gasNumber })
            await tx.wait()

            this.getStakeInfo()
            this.getUnclaimedRewardsForAddress()

            this._showToast$.next({ title: `Claimed` })
        } catch (e) {
            this._errors$.next("Failed to claim")
        }
    }

    stake = async (tokens: number[]) => {
        if (!this.provider || !this._account$.value) return

        const signer = this.provider.getSigner()
        const contract = new ethers.Contract(STAKING_ADDRESS, STAKING_ABI, signer)

        try {
            const gasEstimated = await contract.estimateGas.stakeMany(tokens)
            const gas = Math.ceil(gasEstimated.toNumber() * 1.5)
            const gasNumber = BigNumber.from(gas)

            const tx = await contract.stakeMany(tokens, { gasLimit: gasNumber })
            await tx.wait()

            this.getStakeInfo()
            this.getUserTokens(BOB_MUTANTS_ADDRESS)

            this._showToast$.next({ title: `Staked ${tokens.length} nfts` })
        } catch (e) {
            this._errors$.next("Failed to stake")
        }
    }

    unstake = async (tokens: number[]) => {
        if (!this.provider || !this._account$.value) return

        const signer = this.provider.getSigner()
        const contract = new ethers.Contract(STAKING_ADDRESS, STAKING_ABI, signer)

        try {
            const gasEstimated = await contract.estimateGas.unstakeMany(tokens)
            const gas = Math.ceil(gasEstimated.toNumber() * 1.5)
            const gasNumber = BigNumber.from(gas)

            const tx = await contract.unstakeMany(tokens, { gasLimit: gasNumber })
            await tx.wait()

            this.getStakeInfo()
            this.getUserTokens(BOB_MUTANTS_ADDRESS)

            this._showToast$.next({ title: `Unstaked ${tokens.length} nfts` })
        } catch (e) {
            this._errors$.next("Failed to unstake")
        }
    }

    // SHOP
    getShopActiveItems = async () => {
        const contract = new ethers.Contract(SHOP_ADDRESS, SHOP_ABI, this.provider ?? Web3Service.defaultProvider)

        try {
            this._isLoading$.next(true)
            const items: ShopItem[] = await contract.getActiveItems()
            this._shopActiveItems$.next(items)
        } catch (e) {
            console.log(e)
            this._shopActiveItems$.next([])
        } finally {
            this._isLoading$.next(false)
        }
    }

    isShopManager = async () => {
        const contract = new ethers.Contract(SHOP_ADDRESS, SHOP_ABI, this.provider ?? Web3Service.defaultProvider)

        try {
            if (this._account$.value) {
                const isManager = await contract.isManager(this._account$.value)
                this._isShopManager$.next(isManager)
            } else {
                this._isShopManager$.next(false)
            }
        } catch (e) {
            console.log(e)
            this._isShopManager$.next(false)
        }
    }

    addShopItem = async (
        nftContract: string, tokenId: string, name: string, price: string
    ) => {
        if (!this.provider || !this._account$.value) return

        const signer = this.provider.getSigner()
        const itemContract = new ethers.Contract(nftContract, ERC721_ABI, signer)

        try {
            const isApproved = await itemContract.isApprovedForAll(this._account$.value, SHOP_ADDRESS)
            if (!isApproved) {
                try {
                    const tx = await itemContract.setApprovalForAll(SHOP_ADDRESS, true)
                    await tx.wait()
                } catch (e) {
                    console.log(e)
                    // Wish me luck
                }
            }
        } catch {
            // Wish me luck
        }

        const contract = new ethers.Contract(SHOP_ADDRESS, SHOP_ABI, signer)

        try {
            const gasEstimated = await contract.estimateGas.addItem(nftContract, Number(tokenId), name, ethers.utils.parseEther(price))
            const gas = Math.ceil(gasEstimated.toNumber() * 1.5)
            const gasNumber = BigNumber.from(gas)

            const tx = await contract.addItem(nftContract, Number(tokenId), name, ethers.utils.parseEther(price), { gasLimit: gasNumber })
            await tx.wait()

            this.getShopActiveItems()

            this._showToast$.next({ title: `Item added` })
        } catch (e) {
            this._errors$.next("Failed to add item")
        }
    }

    buyShopItem = async (
        id: number,
        price: BigNumber
    ) => {
        if (!this.provider || !this._account$.value) return

        const signer = this.provider.getSigner()
        const coinContract = new ethers.Contract(COIN_ADDRESS, COIN_ABI, signer)

        try {
            const allowance: BigNumber = await coinContract.allowance(this._account$.value, SHOP_ADDRESS)
            if (price.gt(allowance)) {
                try {
                    const tx = await coinContract.approve(SHOP_ADDRESS, price)
                    await tx.wait()
                } catch (e) {
                    console.log(e)
                    // Wish me luck
                }
            }
        } catch {
            // Wish me luck
        }

        const contract = new ethers.Contract(SHOP_ADDRESS, SHOP_ABI, signer)

        try {
            const gasEstimated = await contract.estimateGas.buyItem(id)
            const gas = Math.ceil(gasEstimated.toNumber() * 1.5)
            const gasNumber = BigNumber.from(gas)

            const tx = await contract.buyItem(id)
            await tx.wait()

            this.getShopActiveItems()

            this._showToast$.next({
                title: `Congratulations!`
            })
        } catch (e) {
            this._errors$.next("Failed to buy item")
        }
    }

    getBobBalance = async () => {
        if (!this.provider || !this._account$.value) {
            this._bobBalance$.next(undefined)
            return
        }

        const coinContract = new ethers.Contract(COIN_ADDRESS, COIN_ABI, this.provider)
        try {
            const balance = await coinContract.balanceOf(this._account$.value)
            this._bobBalance$.next(balance)
        } catch {
            this._bobBalance$.next(undefined)
        }
    }
}