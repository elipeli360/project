import {
  Box,
  Flex,
  Center,
  IconButton,
  HStack,
  Heading,
  SimpleGrid,
  VStack,
  Button,
  Tabs,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Stat,
  StatLabel,
  StatNumber,
} from "@chakra-ui/react";
import Web3Service, { StakeInfo } from "../core/web3.service";
import { useEffect, useState } from "react";
import NFTItemView from "./NFTItemView";
import { BigNumber, ethers } from "ethers";
import { merge, tap } from "rxjs";
import { BOB_MUTANTS_ADDRESS, STAKING_ADDRESS } from "../config";

const StakingView: React.FC = () => {
  const web3Service = Web3Service.shared();

  const [account, setAccount] = useState<string | undefined>(undefined);

  const [tokens, setTokens] = useState<number[]>([]);
  const [stakedTokens, setStakedTokens] = useState<number[]>([]);
  const [isApproved, setIsApproved] = useState<boolean>(false)

  const [selectedTokens, setSelectedTokens] = useState<number[]>([]);
  const [selectedStakedTokens, setSelectedStakedTokens] = useState<number[]>([]);

  const [rewards, setRewards] = useState<BigNumber | undefined>(undefined)
  const [stakeInfo, setStakeInfo] = useState<StakeInfo | undefined>(undefined);

  const unstakedTokens = tokens.filter(token => !stakedTokens.some(t => t == token))

  useEffect(() => {
    web3Service.getUserTokens(BOB_MUTANTS_ADDRESS)
    web3Service.getStakeInfo()
    web3Service.getUnclaimedRewardsForAddress()
    web3Service.isApproved(BOB_MUTANTS_ADDRESS, STAKING_ADDRESS)

    const account$ = web3Service.account$.pipe(
      tap((account) => {
        setAccount(account);
      })
    )

    const rewards$ = web3Service.stakeRewards$.pipe(
      tap((rewards) => {
        setRewards(rewards);
      })
    )

    const tokens$ = web3Service.tokens$.pipe(
      tap((tokens) => {
        setTokens(tokens.map(t => Number(t)));
        setSelectedStakedTokens([])
        setSelectedTokens([])
      })
    )

    const stakedTokens$ = web3Service.stakedTokens$.pipe(
      tap((stakedTokens) => {
        setStakedTokens(stakedTokens.map(t => Number(t)));
        setSelectedStakedTokens([])
        setSelectedTokens([])
      })
    )

    const isApproved$ = web3Service.isApproved$.pipe(
      tap((isApproved) => {
        setIsApproved(isApproved);
      })
    )

    const stakeInfo$ = web3Service.stakeInfo$.pipe(
      tap((stakeInfo) => {
        setStakeInfo(stakeInfo)
      })
    )

    const subscription = merge(
      rewards$,
      tokens$,
      stakedTokens$,
      isApproved$,
      stakeInfo$,
      account$
    ).subscribe()

    return () => {
      subscription.unsubscribe();
    };
  }, [account]);

  let tabs = <>
    <Tabs>
      <Center>
        <TabList>
          <Tab>Available</Tab>
          <Tab>Staked</Tab>
        </TabList>
      </Center>
      <TabPanels>
        <TabPanel>
          <>
            <Center mt={4}>
              <Button
                onClick={() => isApproved ? web3Service.stake(selectedTokens) : web3Service.approveForAll(BOB_MUTANTS_ADDRESS, STAKING_ADDRESS)}
                isDisabled={selectedTokens.length == 0 && isApproved}
                variant={"solid"}
                textColor={'white'}
                border={'2px solid white'}
              >
                {isApproved ? ('Stake' + (selectedTokens.length > 1 ? ` ${selectedTokens.length}` : '')) : `Approve to Stake`}
              </Button>
            </Center>
            <Center mt={4}>
              <HStack>
                <Button
                  onClick={() => {
                    setSelectedTokens(tokens)
                  }}
                  isDisabled={selectedTokens.length == tokens.length}
                  variant={"solid"}
                  textColor={'white'}
                  border={'2px solid white'}
                >
                  Select All
                </Button>
                <Button
                  onClick={() => {
                    setSelectedTokens([])
                  }}
                  isDisabled={selectedTokens.length == 0}
                  variant={"solid"}
                  textColor={'white'}
                  border={'2px solid white'}
                >
                  Deselect All
                </Button>
              </HStack>
            </Center>

            <SimpleGrid
              columns={{ base: 2, md: 4 }}
              spacing={{ base: 4, md: 8 }}
              my={{ base: 4, md: 8 }}
              mx={"auto"}
              maxW={"2xl"}
            >
              {unstakedTokens.map((token, i) => (
                <VStack key={i} spacing={2}
                  onClick={() => {
                    const tokenId = token
                    var copy = selectedTokens
                    if (selectedTokens.some(e => e == tokenId)) {
                      const index = copy.indexOf(token, 0);
                      if (index > -1) {
                        copy.splice(index, 1);
                      }
                    } else {
                      copy.push(token)
                    }
                    setSelectedTokens([...copy])
                  }}
                >
                  <NFTItemView
                    name={`#${token}`}
                    image={`https://ipfs.io/ipfs/bafybeigzumblkhsm3imgsolewyjceoj2blxqucmfv2hpkq34u3lbc6xsh4/${token}.png`}
                    color={selectedTokens.some(d => d == token) ? 'green' : 'white'}
                  />
                </VStack>
              ))}
            </SimpleGrid>
          </>
        </TabPanel>
        <TabPanel>
          <>
            <Center mt={4}>
              <Button
                onClick={() => web3Service.unstake(selectedStakedTokens)}
                isDisabled={selectedStakedTokens.length == 0}
                variant={"solid"}
                textColor={'white'}
                border={'2px solid white'}
              >
                {'Unstake' + (selectedStakedTokens.length > 1 ? ` ${selectedStakedTokens.length}` : '')}
              </Button>
            </Center>

            <Center mt={4}>
              <HStack>
                <Button
                  onClick={() => {
                    setSelectedStakedTokens(stakedTokens)
                  }}
                  isDisabled={selectedStakedTokens.length == stakedTokens.length}
                  variant={"solid"}
                  textColor={'white'}
                  border={'2px solid white'}
                >
                  Select All
                </Button>
                <Button
                  onClick={() => {
                    setSelectedStakedTokens([])
                  }}
                  isDisabled={selectedStakedTokens.length == 0}
                  variant={"solid"}
                  textColor={'white'}
                  border={'2px solid white'}
                >
                  Deselect All
                </Button>
              </HStack>
            </Center>

            <SimpleGrid
              columns={{ base: 2, md: 4 }}
              spacing={{ base: 4, md: 8 }}
              my={{ base: 4, md: 8 }}
              mx={"auto"}
              maxW={"2xl"}
            >
              {stakedTokens.map((token, i) => (
                <VStack key={i} spacing={2}
                  onClick={() => {
                    const tokenId = Number(token)
                    var copy = selectedStakedTokens
                    if (selectedStakedTokens.some(e => e == tokenId)) {
                      const index = copy.indexOf(token, 0);
                      if (index > -1) {
                        copy.splice(index, 1);
                      }
                    } else {
                      copy.push(token)
                    }
                    setSelectedStakedTokens([...copy])
                  }}
                >
                  <NFTItemView
                    name={`#${token}`}
                    image={`https://ipfs.io/ipfs/bafybeigzumblkhsm3imgsolewyjceoj2blxqucmfv2hpkq34u3lbc6xsh4/${token}.png`}
                    color={selectedStakedTokens.some(d => d == token) ? 'green' : 'white'}
                  />
                </VStack>
              ))}
            </SimpleGrid>
          </>
        </TabPanel>
      </TabPanels>
    </Tabs>
  </>

  return (
    <>
      <Box
        mt={8}
        px={4}
      >
        <Box py={4}>
          <Center>
            <Heading textColor={'rgb(255, 255, 255)'}>Staking</Heading>
          </Center>
          {stakeInfo &&
            <SimpleGrid
              textColor={'rgb(255, 255, 255)'}
              columns={{ base: 1, md: 2 }}
              spacing={{ base: 4, md: 8 }}
              my={{ base: 4, md: 8 }}
              mx={"auto"}
              maxW={"3xl"}
            >
              <Stat
                bg={"rgba(0, 0, 0, 0.25)"}
                backdropFilter="auto"
                backdropBlur="4px"
                css={{
                  border: '3px solid transparent',
                  borderImage: 'linear-gradient(to bottom right, #b827fc 0%, #2c90fc 25%, #b8fd33 50%, #fec837 75%, #fd1892 100%)',
                  borderImageSlice: 1
                }}
                boxShadow={"md"}
                py={4}
                px={8}>
                <StatNumber fontSize={'md'}>{stakedTokens.length} staked NFT</StatNumber>
                {rewards && <>
                  <StatLabel mt={4}>Available to claim</StatLabel>
                  <StatNumber>{Number(ethers.utils.formatEther(rewards)).toFixed(2)} BOB</StatNumber>

                  <Center mt={4}>
                    <Button
                      onClick={() => web3Service.claimStakeRewards()}
                      variant={"solid"}
                      textColor={'white'}
                      border={'2px solid white'}
                    >
                      Claim Rewards
                    </Button>
                  </Center>
                </>}
              </Stat>

              <Stat
                bg={"rgba(0, 0, 0, 0.25)"}
                backdropFilter="auto"
                backdropBlur="4px"
                css={{
                  border: '3px solid transparent',
                  borderImage: 'linear-gradient(to bottom right, #b827fc 0%, #2c90fc 25%, #b8fd33 50%, #fec837 75%, #fd1892 100%)',
                  borderImageSlice: 1
                }}
                boxShadow={"md"}
                py={4}
                px={8}>
                <StatLabel>Total Staked</StatLabel>
                <StatNumber>{Number(stakeInfo.totalStaked)}</StatNumber>
                <StatLabel mt={4}>Rate per token</StatLabel>
                <StatNumber>{Number(ethers.utils.formatEther(stakeInfo.dailyRewards)).toFixed(0)} BOB / day</StatNumber>
              </Stat>
            </SimpleGrid>
          }
          {tabs}
        </Box>
      </Box>
    </>
  )
};

export default StakingView;
