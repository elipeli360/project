import {
  AspectRatio,
  Box,
  Button,
  Center,
  Container, Heading, HStack, Image, SimpleGrid, Stat, StatGroup, StatLabel, StatNumber, Text, VStack,
} from "@chakra-ui/react";
import { merge, tap } from "rxjs";

import { useEffect, useState } from "react";
import Web3Service from "../core/web3.service";
import { ethers } from "ethers";

import PlaceholderNFT from "../images/placeholder.gif"
import { Raffle } from "../core/Raffle";

const RaffleView: React.FC = () => {
  const web3Service = Web3Service.shared();

  const [account, setAccount] = useState<string | undefined>(undefined);
  const [pools, setPools] = useState<{ id: number, isRaffleActive: boolean, raffle: Raffle | undefined, title: string | undefined, history: Raffle[] }[]>([]);

  useEffect(() => {
    web3Service.getRaffle()

    const account$ = web3Service.account$.pipe(
      tap((account) => {
        setAccount(account);
      })
    );

    const raffle$ = web3Service.raffles$.pipe(
      tap((pools) => {
        setPools(pools)
      })
    );

    const subscription = merge(
      account$,
      raffle$,
    ).subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [account]);

  return (
    <>
      <VStack
        width={'100%'}
        spacing={16}
        my={{ base: 4, md: 8 }}
        mx={"auto"}
        px={4}
      >
        <SimpleGrid
          columns={{ base: 1, md: 2, lg: 4 }}
          spacing={{ base: 4, md: 8 }}
        >
          {pools.map((pool, index) => <RafflePoolView key={index} poolId={pool.id} isRaffleActive={pool.isRaffleActive} title={pool.title} raffle={pool.raffle} history={pool.history} />)}
        </SimpleGrid>
      </VStack>
    </>
  );
};

export default RaffleView;

interface RafflePoolProps {
  poolId: number
  isRaffleActive: boolean
  title: string | undefined
  raffle: Raffle | undefined
  history: Raffle[]
}

const RafflePoolView: React.FC<RafflePoolProps> = (props) => {
  const { poolId, title, raffle, history, isRaffleActive } = props
  const [image, setImage] = useState<string | undefined>(undefined);
  const web3Service = Web3Service.shared();

  const finished = !isRaffleActive
  const drawn = raffle ? Number(raffle.players.length) > 0 : false
  const status = raffle ? (raffle.paused ? 'Paused' : finished ? (drawn ? 'Finished' : 'Cancelled') : 'Active') : 'Inactive'

  useEffect(() => {
    let isSubscribed = true
    const fetchImage = async () => {

      if (raffle) {
        const imageUrl = await web3Service.getImage(raffle.nftContract, Number(raffle.tokenId))

        if (isSubscribed) {
          setImage(imageUrl);
        }
      } else {
        if (isSubscribed) {
          setImage(undefined);
        }
      }
    }

    fetchImage().catch()

    return () => {
      isSubscribed = false
    }
  }, []);

  return <>
    <Box>
      <Box
        my={4}
        bg={"rgba(50, 50, 50, 0.5)"}
        rounded={"xl"}
        boxShadow={"md"}
        maxWidth={480}
      >
        <Center mb={2}>
          <Heading fontSize={'2xl'}>{title}</Heading>
        </Center>
        <StatGroup>
          <Stat
            width={128}
            p={4}>
            <StatLabel>Status</StatLabel>
            <StatNumber fontSize={'xl'} textColor={'purple.200'}>{status}</StatNumber>
          </Stat>

          {
            raffle &&
            <Stat
              width={128}
              p={4}>
              <StatLabel>Players</StatLabel>
              <StatNumber fontSize={'xl'} textColor={'purple.200'}>{raffle.players.length}/{Number(raffle.playerLimit)}</StatNumber>
            </Stat>
          }

          {
            raffle &&
            <Stat
              width={128}
              p={4}>
              <StatLabel>Price</StatLabel>
              <StatNumber fontSize={'xl'} textColor={'purple.200'}>{Number(ethers.utils.formatEther(raffle.ticketPrice)).toFixed(0)} CRO</StatNumber>
            </Stat>
          }

        </StatGroup>

        <Container centerContent my={4}>
          <AspectRatio w='100%' maxW={'256px'} ratio={1}>
            <Image borderRadius={'lg'} objectFit={'cover'} css={{
              border: '3px solid black',
            }}
              src={image ?? PlaceholderNFT} />
          </AspectRatio>
          {
            raffle &&
            <VStack mt={4} spacing={0}>
              <Text fontSize={'md'} fontWeight={500} textColor={'purple.100'}>{raffle.name} #{Number(raffle.tokenId)}</Text>
              {Number(raffle.rank) > 0 && <Text fontSize={'md'} textColor={'purple.100'}>Rank {Number(raffle.rank)}</Text>}
              <Text fontSize={'xs'}>{raffle.nftContract}</Text>
            </VStack>
          }
          <HStack>
            <Button my={4} hidden={finished || raffle == undefined} isDisabled={(raffle?.paused ?? true) || poolId == -1 || finished} onClick={() => web3Service.joinRaffle(poolId)}>Join</Button>
            {raffle && finished && raffle.players.length > 0 && <Text fontWeight={700}>Winner: {raffle.winner.slice(0, 6)}...{raffle.winner.slice(-4)}</Text>}
          </HStack>
        </Container>

        <Stat
          width={256}
          p={4}>
          <StatLabel>Winners History</StatLabel>
          <StatNumber fontSize={'md'} textColor={'purple.200'}>
            <VStack>
              {history.length > 0 ?
                history.map(r => r.winner).slice(-5).map(item => <Text>{item.slice(0, 6)}...{item.slice(-4)}</Text>).reverse()
                :
                <Text>No winners yet</Text>
              }
            </VStack>
          </StatNumber>
        </Stat>
      </Box>
    </Box>

  </>
};  