import {
  Box,
  Flex,
  Center,
  IconButton,
  HStack,
  Heading,
  StatGroup,
  Stat,
  StatLabel,
  Container,
  AspectRatio,
  Image,
  VStack,
  StatNumber,
  Text,
  Button,
  SimpleGrid,
  Alert,
  AlertIcon,
  AlertTitle,
  AlertDescription,
  Divider,
  Wrap,
  WrapItem,
  NumberInput,
  NumberInputField,
  Input,
} from "@chakra-ui/react";
import Web3Service from "../core/web3.service";
import { useEffect, useState } from "react";
import { BigNumber, ethers } from "ethers";
import PlaceholderNFT from "../images/placeholder.gif"
import { merge, tap } from "rxjs";
import { isAddress } from "ethers/lib/utils";

export type ShopItem = { id: BigNumber, status: BigNumber, nftContract: string, tokenId: BigNumber, name: string, price: BigNumber }

const ShopItemView: React.FC<{ item: ShopItem }> = (props) => {
  const { item } = props
  const [image, setImage] = useState<string | undefined>(undefined);
  const web3Service = Web3Service.shared();

  useEffect(() => {
    let isSubscribed = true
    const fetchImage = async () => {

      const imageUrl = await web3Service.getImage(item.nftContract, Number(item.tokenId))

      if (isSubscribed) {
        setImage(imageUrl);
      }
    }

    fetchImage().catch()

    return () => {
      isSubscribed = false
    }
  }, []);

  return <>
    <Box
      bg={"rgba(0, 0, 0, 0.25)"}
      backdropFilter="auto"
      backdropBlur="4px"
      css={{
        border: '3px solid transparent',
        borderImage: 'linear-gradient(to bottom right, #b827fc 0%, #2c90fc 25%, #b8fd33 50%, #fec837 75%, #fd1892 100%)',
        borderImageSlice: 1
      }}
      boxShadow={"md"}
      minW={'256px'}
    >
      <Container centerContent mt={4}>
        <AspectRatio w='100%' maxW={'256px'} ratio={1}>
          <Image borderRadius={'lg'} objectFit={'cover'} css={{
            border: '3px solid black',
          }}
            src={image ?? PlaceholderNFT} />
        </AspectRatio>
        <VStack spacing={0}>
          <Text fontSize={'md'} fontWeight={500} textColor={'purple.100'}>{item.name} #{Number(item.tokenId)}</Text>
          <Text fontSize={'xs'} fontWeight={400} textColor={'purple.300'}>{item.nftContract.slice(0, 6)}...{item.nftContract.slice(-4)}</Text>
        </VStack>
        <Stat mt={2}>
          <StatNumber fontSize={'sm'} textColor={'purple.200'}>{Number(ethers.utils.formatEther(item.price)).toFixed(0)} BOB</StatNumber>
        </Stat>
        <Button my={2} onClick={() => web3Service.buyShopItem(Number(item.id), item.price)}>Buy</Button>
      </Container>
    </Box>

  </>
};

const ShopView: React.FC = () => {
  const web3Service = Web3Service.shared();

  const [account, setAccount] = useState<string | undefined>(undefined);
  const [isManager, setIsManager] = useState<boolean>(false);
  const [items, setItems] = useState<ShopItem[]>([]);

  useEffect(() => {
    web3Service.getShopActiveItems()
    web3Service.isShopManager()

    const account$ = web3Service.account$.pipe(
      tap((account) => {
        setAccount(account);
      })
    );

    const items$ = web3Service.shopActiveItems$.pipe(
      tap((items) => {
        setItems(items)
      })
    );

    const isManager$ = web3Service.isShopManager$.pipe(
      tap((isManager) => {
        setIsManager(isManager)
      })
    );

    const subscription = merge(
      account$,
      items$,
      isManager$,
    ).subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [account]);

  return (
    <>
      {
        items.length > 0 ?
          <VStack
            width={'100%'}
            my={{ base: 4, md: 8 }}
            mx={"auto"}
            px={4}
            maxW={'8xl'}
          >
            <Wrap justify='center' spacing={8}>
              {items.map((item, index) => <WrapItem key={`${index}_${Number(item.id)}`}><ShopItemView item={item} /></WrapItem>)}
            </Wrap>
          </VStack>
          :
          <Center mt={16} p={4}>
            <Alert
              py={8}
              maxWidth={'360px'}
              status='warning'
              variant='subtle'
              flexDirection='column'
              alignItems='center'
              justifyContent='center'
              textAlign='center'
              backdropFilter="auto"
              backdropBlur="4px"
              css={{
                border: '3px solid transparent',
                borderImage: 'linear-gradient(to bottom right, #b827fc 0%, #2c90fc 25%, #b8fd33 50%, #fec837 75%, #fd1892 100%)',
                borderImageSlice: 1
              }}
              boxShadow={"md"}
            >
              <AlertIcon boxSize='40px' mr={0} />
              <AlertTitle mt={4} mb={1} fontSize='lg'>
                No Items
              </AlertTitle>
              <AlertDescription maxWidth='sm'>
                Thanks for checking our shop. Sadly there is no any items available right now.
              </AlertDescription>
              <AlertDescription maxWidth='sm'>
                Come back later!
              </AlertDescription>
            </Alert>
          </Center>
      }

      {
        isManager ?
          <ShopManagerView />
          :
          undefined
      }
    </>
  );
};

export default ShopView;

const ShopManagerView: React.FC = () => {
  const web3Service = Web3Service.shared();

  const [account, setAccount] = useState<string | undefined>(undefined);

  const [contract, setContract] = useState('')
  const [tokenId, setTokenId] = useState('')
  const [name, setName] = useState('')
  const [price, setPrice] = useState('')

  const handleContract = (event) => setContract(event.target.value)
  const handleTokenId = (event) => setTokenId(event.target.value)
  const handleName = (event) => setName(event.target.value)
  const handlePrice = (event) => setPrice(event.target.value)

  const isNumber = !isNaN(+tokenId)

  useEffect(() => {
    web3Service.getShopActiveItems()
    web3Service.isShopManager()

    const account$ = web3Service.account$.pipe(
      tap((account) => {
        setAccount(account);
      })
    );

    const subscription = merge(
      account$,
    ).subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [account]);

  return (
    <>
      <Center mt={8}><Heading>Add Item</Heading></Center>
      <Center>
        <VStack mt={8} maxW={'6xl'} spacing={8}>
          <Box minW={'360px'}>
            <Text textAlign={'center'}>Collection Address</Text>
            <Input
              isInvalid={!isAddress(contract)}
              value={contract}
              onChange={handleContract}
              size='sm'
              bg={'rgba(0, 0, 0, 0.3)'}
            />
          </Box>

          <Box minW={'360px'}>
            <Text textAlign={'center'}>Token</Text>
            <NumberInput
              mt={2}
              size='sm'
              bg={'rgba(0, 0, 0, 0.3)'}
            >
              <NumberInputField
                onChange={handleTokenId}
              />
            </NumberInput>
          </Box>

          <Box minW={'360px'}>
            <Text textAlign={'center'}>Name</Text>
            <Input
              isInvalid={!(name.length > 0)}
              value={name}
              onChange={handleName}
              size='sm'
              bg={'rgba(0, 0, 0, 0.3)'}
            />
          </Box>

          <Box minW={'360px'}>
            <Text textAlign={'center'}>Price</Text>
            <NumberInput
              mt={2}
              size='sm'
              bg={'rgba(0, 0, 0, 0.3)'}
            >
              <NumberInputField
                onChange={handlePrice}
              />
            </NumberInput>
          </Box>
          <Center><Button my={4} isDisabled={contract.length < 1 || tokenId.length < 1 || name.length < 1 || price.length < 1} onClick={() => web3Service.addShopItem(contract, tokenId, name, price)}>Add Item</Button></Center>
        </VStack>
      </Center>
    </>
  );
};