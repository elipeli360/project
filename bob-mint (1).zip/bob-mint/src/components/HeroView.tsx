import {
  Box,
  Center,
  Button,
  Heading,
  Tooltip,
  VStack,
  Checkbox,
  Container,
  Text,
  Image,
  Slider,
  SliderTrack,
  SliderFilledTrack,
  SliderThumb,
  SimpleGrid,
  Link,
  HStack
} from "@chakra-ui/react";
import { merge, tap } from "rxjs";

import { useEffect, useState } from "react";
import { MintInfo } from "../core/MintInfo";
import Web3Service from "../core/web3.service";
import SampleImage from "../images/sample.gif";

interface HeroViewProps {
}

const HeroView: React.FC<HeroViewProps> = () => {
  const web3Service = Web3Service.shared();

  const [sliderValue, setSliderValue] = useState(1)
  const [showTooltip, setShowTooltip] = useState(false)

  const [isWhitelisted, setIsWhitelisted] = useState(false)
  const [account, setAccount] = useState<string | undefined>(undefined);
  const [mintInfo, setMintInfo] = useState<MintInfo | undefined>(undefined);

  useEffect(() => {
    web3Service.getMintInfo();

    const account$ = web3Service.account$.pipe(
      tap((account) => {
        setAccount(account);
      })
    );

    const mintInfo$ = web3Service.mintInfo$.pipe(
      tap((mintInfo) => {
        setMintInfo(mintInfo);
      })
    );

    const subscription = merge(
      mintInfo$,
      account$
    ).subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [account]);

  useEffect(() => {
    web3Service.isWhitelisted()

    const isWhitelisted$ = web3Service.isWhitelisted$.pipe(
      tap((isWhitelisted) => {
        setIsWhitelisted(isWhitelisted);
      })
    );

    const subscription = merge(
      isWhitelisted$,
    ).subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [account])

  let buttonEnabled: boolean
  let buttonTitle: string

  let dateInfo
  let whitelistLabel

  if (mintInfo) {
    const now = new Date()
    const publicDate = new Date(Number(mintInfo.publicTimestamp) * 1000)

    dateInfo = <VStack>
      <Text>Date</Text>
      <Text textAlign={'center'}><b>{publicDate.toLocaleString(undefined, { dateStyle: 'short', timeStyle: 'short' })}</b></Text>
    </VStack>

    if (isWhitelisted) {
      whitelistLabel = <>
        <Center pt={8}>
          <Heading as="h2" size="md" fontWeight="bold" textShadow={'lg'}>
            You are whitelisted!
          </Heading>
        </Center>
      </>
    }

    if (now < publicDate) {
      buttonTitle = "Coming Soon"
      buttonEnabled = false
    } else if (mintInfo.isPaused) {
      buttonTitle = "Paused"
      buttonEnabled = false
    } else {
      if (Number(mintInfo.maxSupply) > Number(mintInfo.supply)) {
        buttonTitle = sliderValue > 1 ? `Mint ${sliderValue}` : "Mint"
        buttonEnabled = true
      } else {
        buttonTitle = "Sold Out"
        buttonEnabled = false
      }
    }
  } else {
    buttonTitle = "Loading"
    buttonEnabled = false
  }

  let startInfo = <>
    {dateInfo}

    <SimpleGrid
      pt={8}
      textAlign='center'
      columns={{ base: 1, md: 1 }}
      spacing={{ base: 2, md: 2 }}
      mx={"auto"}
      px={4}
    >
      <Heading fontSize={'2xl'}>Price</Heading>
      <Text>Public: <b>220 CRO</b></Text>
      <Text>Whitelist: <b>198 CRO</b></Text>
    </SimpleGrid>
  </>

  let amountSlider = <>
    <Center paddingTop={8}>
      <Slider
        id='mint-amount'
        defaultValue={1}
        min={1}
        max={Number(mintInfo?.maxMint ?? 0)}
        colorScheme='brand'
        onChange={(v) => setSliderValue(v)}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
      >
        <SliderTrack>
          <SliderFilledTrack />
        </SliderTrack>
        <Tooltip
          hasArrow
          bg='rgb(255, 255, 255)'
          color='black'
          placement='top'
          isOpen={showTooltip}
          label={sliderValue}
        >
          <SliderThumb />
        </Tooltip>
      </Slider>
    </Center>
  </>

  let mintedStatsView = <>
    <Center pt={4}>
      <VStack>
        {startInfo}
        <Heading pt={4} fontSize={'xl'} > {mintInfo?.supply.toString() ?? '-'}/{mintInfo?.maxSupply.toString() ?? '-'} minted</Heading>
      </VStack>
    </Center>
  </>

  return (
    <>
      <Container centerContent maxWidth={896} mt={8}
        bg={"rgba(0, 0, 0, 0.35)"}
        textColor={'rgb(255, 255, 255)'}
        rounded={"xl"}
        boxShadow={"md"}
      >
        <Box
          maxWidth={860}
          py={{ base: 4, md: 8 }}
          px={{ base: 2, md: 16 }}
        >
          <Center mt={4}>
            <Image src={SampleImage}
              boxSize={64}
              rounded={"xl"}
              boxShadow={"md"}
            />
          </Center>
          <Center mt={8}>
            <Box>
              <Box textAlign={"center"}>
                <Heading fontSize={{ base: 'xl', sm: 'xl', md: '3xl' }} fontWeight={"medium"}>
                  BOB Mutants
                </Heading>
                <Text pt={8}>BOB Mutants is a super limited collection of <b>1111 NFTs</b> with more than <b>125 traits</b>. If you are lucky you can find one of our <b>14 legendaries</b> that are hiding in our BOB Mutant collection. <b>Find legendary</b> mutant and you will <b>be rewarded</b>. BOB Mutants will unlock brand new utility - <b>BOB Shop</b> where you will be able to buy NFTs from different Cronos collections using BOB token. You will be able to stake BOB Mutants on our website to earn BOB token. <b>You can get BOB token ONLY by staking BOB Mutant</b>. The more BOB Mutants you stake, the more you earn. Tokens can be used in our raffles and in future we will add more utility. Of course just like any other BOB Adventures collection, by holding BOB Mutant you will get automatic WL to upcoming gens, unlock DAO and future contests/giveaways for holders.</Text>
                <Text>+ <b>Every 10 BOB Mutants = 1 CronosWeed gen2 airdrop!</b></Text>
              </Box>
            </Box>
          </Center>

          <Center>
            <Box paddingTop={8} position={"relative"} maxWidth={640}>
              {mintedStatsView}
              {buttonEnabled ? amountSlider : undefined}
              {whitelistLabel}

              <Center>
                <Button
                  mt={8}
                  onClick={() => web3Service.mint(sliderValue)}
                  isDisabled={!buttonEnabled}
                  variant={"solid"}
                  colorScheme={'brand'}
                >
                  {buttonTitle}
                </Button>
              </Center>
            </Box>
          </Center>
        </Box>
      </Container>
    </>
  );
};

export default HeroView;