import {
    Box,
    Center,
    Divider,
    Heading,
    HStack,
    SimpleGrid,
    Link,
    Text,
    Container,
    Button,
    Stat,
    StatLabel,
    StatNumber,
    useColorModeValue,
    Select
} from "@chakra-ui/react";
import { useEffect, useState } from "react";
import { merge, tap } from "rxjs";
import { BOB_MUTANTS_ADDRESS, CONTRACT_ADDRESS, SPACESHIPS_ADDRESS } from "../config";
import Web3Service from "../core/web3.service";

import NFTItemView from "./NFTItemView";

interface GalleryViewProps { }

const GalleryView: React.FC<GalleryViewProps> = (props) => {
    const web3Service = Web3Service.shared();

    const [collectionOption, setCollectionOption] = useState<number>(0);
    const [account, setAccount] = useState<string | undefined>(undefined);
    const [tokens, setTokens] = useState<number[]>([]);

    useEffect(() => {
        const account$ = web3Service.account$.pipe(
            tap((account) => {
                setAccount(account);
            })
        );

        const tokens$ = web3Service.tokens$.pipe(
            tap((tokens) => {
                setTokens(tokens);
            })
        );

        const subscription = merge(
            tokens$,
            account$
        ).subscribe();

        return () => {
            subscription.unsubscribe();
        };
    }, [account]);


    useEffect(() => {
        let collectionAddress: string
        switch (collectionOption) {
            case 1:
                collectionAddress = SPACESHIPS_ADDRESS
                break;
            case 2:
                collectionAddress = BOB_MUTANTS_ADDRESS
                break;
            default: // 0
                collectionAddress = CONTRACT_ADDRESS
                break;
        }

        setTokens([])
        web3Service.getUserTokens(collectionAddress);
    }, [account, collectionOption]);

    let imagesBaseUri: string
    switch (collectionOption) {
        case 1:
            imagesBaseUri = "https://wsrv.nl/?url=https://bafybeifl3vxhslear4rrrifbn33ehs2qfemxvpspvsqtgb5i342sgewep4.ipfs.nftstorage.link/{token}.png&w=256"
            break;
        case 2:
            imagesBaseUri = "https://wsrv.nl/?url=https://bafybeigzumblkhsm3imgsolewyjceoj2blxqucmfv2hpkq34u3lbc6xsh4.ipfs.nftstorage.link/{token}.png&w=256"
            break;
        default: // 0
            imagesBaseUri = "https://wsrv.nl/?url=https://bafybeif5yr3jzibgvozr4m6kjp627vhgts5ldmkogmqgctbec4ty22q4za.ipfs.nftstorage.link/{token}.png&w=256"
            break;
    }

    let content = <>
        <SimpleGrid
            columns={{ base: 1, md: 2 }}
            spacing={{ base: 4, md: 8 }}
            my={{ base: 4, md: 8 }}
            mx={"auto"}
            px={4}
            maxW={"6xl"}
        >
            <Stat bg={useColorModeValue(
                "rgba(247, 250, 252, 0.5)",
                "rgba(23, 25, 35, 0.5)"
            )}
                rounded={"xl"}
                boxShadow={"md"}
                p={4}>
                <StatLabel>Address</StatLabel>
                <StatNumber fontSize={{ base: 'sm', md: 'md' }}>{account}</StatNumber>
            </Stat>

            <Stat bg={useColorModeValue(
                "rgba(247, 250, 252, 0.5)",
                "rgba(23, 25, 35, 0.5)"
            )}
                rounded={"xl"}
                boxShadow={"md"}
                p={4}>
                <StatLabel>Owned</StatLabel>
                <StatNumber fontSize={{ base: 'sm', md: 'md' }}>{tokens.length}</StatNumber>
            </Stat>
        </SimpleGrid>

        <SimpleGrid
            columns={{ base: 2, md: 4 }}
            spacing={{ base: 4, md: 8 }}
            my={{ base: 4, md: 8 }}
            mx={"auto"}
            maxW={"4xl"}
        >
            {tokens.map((token, i) => (
                <Link key={`${collectionOption}_${i}`} href={imagesBaseUri.replace("{token}", `${token}`)} isExternal>
                    <NFTItemView
                        name={`#${token}`}
                        image={imagesBaseUri.replace("{token}", `${token}`)}
                        color={undefined}
                    />
                </Link>
            ))}
        </SimpleGrid>
    </>

    let emptyView = <>
        <Center mt={8}>
            <Text maxW={'2xl'}>You do not own any currently</Text>
        </Center>
    </>

    let connectWallet = <>
        <Container>
            <Center mt={8}>
                <Text maxW={'2xl'}>Connect Wallet to see the NFTs you own</Text>
            </Center>
            <Center mt={8}>
                <Button size={{ base: 'sm', sm: 'sm', md: 'md' }} onClick={web3Service.toggleConnect}>
                    {"Connect Wallet"}
                </Button>
            </Center>
        </Container>
    </>

    let picker = <>
        <Select variant={'filled'} value={collectionOption} onChange={(option) => {
            setCollectionOption(Number(option.target.value))
        }}>
            <option value={0}>BOB Gen2</option>
            <option value={1}>Spaceships</option>
            <option value={2}>BOB Mutants</option>
        </Select>
    </>

    return (
        <>
            <Center my={8}>
                <Box>
                    {account ? picker : undefined}
                    {account ? (tokens.length > 0 ? content : emptyView) : connectWallet}
                </Box>
            </Center>
        </>
    );
};

export default GalleryView;
