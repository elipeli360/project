import {
  Box,
  Button,
  Center,
  Heading,
  Input,
} from "@chakra-ui/react";
import { ethers } from "ethers";
import { useState } from "react";
import Web3Service from "../core/web3.service";
import { RAFFLE_ADDRESS } from "../config";

const ApproveView: React.FC = () => {
  const web3Service = Web3Service.shared();

  const [value, setValue] = useState('')
  const handleChange = (event) => setValue(event.target.value)

  const isAddress = ethers.utils.isAddress(value)

  return (
    <>
      <Center mt={16} mb={8}>
        <Box>
          <Heading textAlign={"center"}>Approve ERC721</Heading>

          <Input
            mt={16}
            isInvalid={!isAddress}
            value={value}
            onChange={handleChange}
            placeholder='ERC721 contract address'
            size='sm'
          />
          <Center><Button my={4} isDisabled={!isAddress} onClick={() => web3Service.approveForAll(value, RAFFLE_ADDRESS)}>Approve for All</Button></Center>
        </Box>
      </Center>
    </>
  );
};

export default ApproveView;
