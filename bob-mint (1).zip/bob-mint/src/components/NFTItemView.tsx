import { Avatar, Box, Flex, Heading, Image } from "@chakra-ui/react";

interface NFTItemViewProps {
  name: string,
  image: string,
  color: string | undefined
}

const NFTItemView: React.FC<NFTItemViewProps> = (props) => {
  const { name, image, color } = props;

  return (
    <>
      <Flex
        w="full"
        alignItems="center"
        justifyContent="center"
      >
        <Flex
          direction="column"
          justifyContent="center"
          alignItems="center"
          w="sm"
          mx="auto">

          <Image src={image} boxSize={{ base: '80%', md: '100%' }} css={{
            border: `3px solid ${color ?? 'rgb(255, 255, 255)'}`,
          }} />

          <Box
            zIndex={2}
            css={{
              border: `2px solid ${color ?? 'rgb(255, 255, 255)'}`,
            }}
            bg='rgba(0, 0, 0, 0.7)'
            mt={-5}
            shadow="lg"
            rounded="sm"
            px={8}
            overflow="hidden"
          >
            <Heading
              py={2}
              textAlign="center"
              fontWeight="bold"
              fontSize={'sm'}
              textTransform="uppercase"
              color="white"
              letterSpacing={1}
            >
              {name}
            </Heading>
          </Box>
        </Flex>
      </Flex>
    </>
  );
};

export default NFTItemView;
