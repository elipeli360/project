import {
  Box,
  Flex,
  Center,
  IconButton,
  HStack,
} from "@chakra-ui/react";

interface FooterViewProps { }

const FooterView: React.FC<FooterViewProps> = (props) => {
  return (
    <>
      <Box
        mt={8}
        px={4}
      >
        <Box py={4}>
          <Center>
            <Box textColor={'rgb(255, 255, 255)'}>Copyright © 2023 BOB Adventures</Box>
          </Center>
        </Box>
      </Box>
    </>
  );
};

export default FooterView;
