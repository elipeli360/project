import {
  Image,
  Button,
  useColorMode,
  Tooltip,
  Container,
  HStack,
  VStack,
  Wrap,
  Text,
} from "@chakra-ui/react";

import HeaderImage from "../images/header.webp";

import {
  Link
} from "react-router-dom";

import { FaDiscord, FaTwitter } from "react-icons/fa";
import Web3Service from "../core/web3.service";
import { useEffect, useState } from "react";
import { merge, tap } from "rxjs";
import { BigNumber, ethers } from "ethers";

interface HeaderNavigationProps {
  isConnected: boolean
  account: string | undefined
  isCorrectChainId: boolean
  toggleConnect: () => void
  switchNetwork: () => void
}

const HeaderNavigation: React.FC<HeaderNavigationProps> = (props) => {
  const account = props.account

  const web3Service = Web3Service.shared();
  const [balance, setBalance] = useState<BigNumber | undefined>(undefined);

  useEffect(() => {
    web3Service.getBobBalance()

    const balance$ = web3Service.bobBalance$.pipe(
      tap((balance) => {
        setBalance(balance);
      })
    );

    const subscription = merge(
      balance$
    ).subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [account]);

  // const handleTwitterClick = () => {
  //   window.open("");
  // }

  // const handleDiscordClick = () => {
  //   window.open("");
  // }

  return (
    <>
      <Container centerContent>
        <VStack>
          <Image src={HeaderImage} mt={4} />
          <VStack mt={8} pt={{ base: 8, md: 0 }}>
            {/* <HStack >
            <Button colorScheme="brand" variant={'ghost'} size='md' onClick={handleTwitterClick}>
              {<FaTwitter />}
            </Button>
            <Button colorScheme="brand" variant={'ghost'} size='md' onClick={handleDiscordClick}>
              {<FaDiscord  />}
            </Button>
          </HStack> */}
            <HStack>
              <Tooltip label={account ? `${account.slice(0, 6)}...${account.slice(-4)}` : null}>
                <Button size={'md'} variant={'outline'} onClick={props.toggleConnect}>
                  {props.isConnected ? "Disconnect" : "Connect Wallet"}
                </Button>
              </Tooltip>
            </HStack>
          </VStack>
          <Wrap textColor='white' my={8} px={8} justify={'center'}>
            <Link to="/"><Button variant={'ghost'} colorScheme={'brand'}>Home</Button></Link>
            <Link to="/explore"><Button variant={'ghost'} colorScheme={'brand'}>Explore</Button></Link>
            <Link to="/royalties"><Button variant={'ghost'} colorScheme={'brand'}>Royalties</Button></Link>
            <Link to="/raffles"><Button variant={'ghost'} colorScheme={'brand'}>Raffles</Button></Link>
            <Link to="/staking"><Button variant={'ghost'} colorScheme={'brand'}>Staking</Button></Link>
            <Link to="/shop"><Button variant={'ghost'} colorScheme={'brand'}>Shop</Button></Link>
          </Wrap>
          {balance && <Text>Balance: <b>{Number(ethers.utils.formatEther(balance)).toLocaleString('en-US', { maximumFractionDigits: 2 })} BOB</b></Text>}
        </VStack>
      </Container>
    </>
  );
};

export default HeaderNavigation;
